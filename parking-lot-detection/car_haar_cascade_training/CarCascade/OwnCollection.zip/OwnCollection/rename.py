import os
import cv2
import numpy as np

def create_negative_description_file(path,file_name):
    for image in os.listdir(path):
        line = path+'\\'+image
        with open(file_name,'a') as f:
            f.write(line)
            f.write('\n')
            
create_negative_description_file(r'C:\Users\BAG\Desktop\CarCascade\NegativeImages','bg.txt')